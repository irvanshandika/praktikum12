<?php echo e($slot); ?>

<?php /**PATH D:\Pemrograman\pemrograman_web\praktikum11\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/subcopy.blade.php ENDPATH**/ ?>